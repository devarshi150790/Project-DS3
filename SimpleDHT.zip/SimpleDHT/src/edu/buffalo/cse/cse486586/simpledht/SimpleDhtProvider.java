package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;


import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class SimpleDhtProvider extends ContentProvider {

	public String portStr="";
	public String succ="";
	public String pred="";
	public int count=0;
	public String ip="10.0.2.2";
	public MatrixCursor mcursor=null;
	public int dne=0;
	public boolean flag=false;
	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		String key=values.get("key").toString();
		String value = values.get("value").toString();
		{
			FileOutputStream fos;
			try
			{
				flag = false;
				flag=returnVal(key, pred, portStr);
				
				if(flag)
				{
					fos = getContext().openFileOutput(key, Context.MODE_WORLD_READABLE);
					fos.write(value.getBytes());
					fos.close();
				}
				else if(!flag)
				{
					Socket clientSocket = new Socket(InetAddress.getByName(ip),getPortNo(succ));
					DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());
					dos.writeBytes("Successor:"+succ+":"+key+":"+value);
					dos.close();
					clientSocket.close();
				}
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public boolean onCreate() {
		
		TelephonyManager tel = (TelephonyManager) this.getContext().getSystemService(Context.TELEPHONY_SERVICE);
		portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		ServerTask s = new ServerTask();
		s.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

		ClientTask cT = new ClientTask();
		cT.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);

		return false;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
			String sortOrder) {
		FileInputStream fis;
		try {
			MatrixCursor mcu=new MatrixCursor(new String[]{"key","value"});
			if(selection.equals("Gdump"))
			{
				String files[]=getContext().fileList();
				for(int i=0;i<files.length;i++)
				{
					fis = getContext().openFileInput(files[i]);	
					BufferedReader br = new BufferedReader(new InputStreamReader(fis));
					String value = br.readLine();
					mcu.addRow(new String[]{files[i],value});
				}
				return (Cursor)mcu;
			}
			else if(selection.equals("Ldump"))
			{
				String files[]=this.getContext().fileList();
				flag=false;
				for(int i=0;i<files.length;i++)
				{
					fis = this.getContext().openFileInput(files[i]);	
					BufferedReader br = new BufferedReader(new InputStreamReader(fis));
					String value = br.readLine();
					flag = false;
					
					flag=returnVal(files[i], pred, portStr);
					
					if(flag)
					mcu.addRow(new String[]{files[i],value});
					br.close();
					fis.close();
				}
				return (Cursor)mcu;


			}
			else
			{
				flag = false;
				flag=returnVal(selection, pred, portStr);
				if(flag)
				{
					fis = getContext().openFileInput(selection);	
					BufferedReader br = new BufferedReader(new InputStreamReader(fis));
					String value = br.readLine();
					Log.v("Value Read:",value);
					mcu.addRow(new String[]{selection,value});
					return (Cursor)mcu;
				}
				else if(!flag)
				{
					Socket clientSocket = new Socket(InetAddress.getByName(ip),getPortNo(succ));
					DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());
					dos.writeBytes("QuerySucc:"+succ+":"+selection+":"+1);
					dos.close();
					clientSocket.close();

					while(dne==0){}
					if(mcursor!=null && dne==2)
					{
						mcursor.moveToFirst();
						dne=0;
						return (Cursor)mcursor;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean returnVal(String key, String pred, String portStr)
	{
		try {
			if(genHash(pred).compareTo(genHash(portStr))>=0 &&
					(genHash(key).compareTo(genHash(pred))>0||genHash(key).compareTo(genHash(portStr))<=0))
				return true;
			else if(genHash(key).compareTo(genHash(portStr))<=0 && genHash(key).compareTo(genHash(pred))>0)
				return true;
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	private String genHash(String input) throws NoSuchAlgorithmException {
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		byte[] sha1Hash = sha1.digest(input.getBytes());
		Formatter formatter = new Formatter();
		for (byte b : sha1Hash) {
			formatter.format("%02x", b);
		}
		return formatter.toString();
	}

	public Uri buildUri(String scheme, String authority) {
		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority(authority);
		uriBuilder.scheme(scheme);
		return uriBuilder.build();
	}

	public int getPortNo(String portStr)
	{
		if(portStr.equals("5554"))
			return 11108;
		
		else if(portStr.equals("5556"))
			return 11112;
		
		else
			return 11116;
	}


	
	
	public class ServerTask extends AsyncTask<Void, String, Void>{

		@Override
		protected Void doInBackground(Void... params) {

			try {
				ServerSocket serverSocket = new ServerSocket(10000);
				while(true)
				{
					Socket clientSocket = serverSocket.accept();

					BufferedReader br=new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

					String inputline=br.readLine();

					if(inputline.contains("Successor"))
					{
						Uri uri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");
						String key  = inputline.split(":")[2];
						String value = inputline.split(":")[3];
						ContentValues cv = new ContentValues();
						cv.put("key", key);
						cv.put("value",value);
						insert(uri,cv);
					}
					else if(inputline.contains("QuerySucc"))
					{
						Uri uri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");
						String temp[]= inputline.split(":");
						String key = temp[2];
						dne=Integer.parseInt(temp[3]);
						Cursor mcr = query(uri, null, key, null, null);
						if(mcr!=null)
						{
							Socket clSoc = new Socket(InetAddress.getByName(ip),getPortNo(pred));
							DataOutputStream dos=new DataOutputStream(clSoc.getOutputStream());
							mcr.moveToFirst();
							dos.writeBytes("GOahead:"+pred+":"+mcr.getString(mcr.getColumnIndex("key"))+":"+mcr.getString(mcr.getColumnIndex("value")));
							dos.close();
							clSoc.close();
							dne=0;
						}
					}
					else if(inputline.contains("GOahead"))
					{
						String key = inputline.split(":")[2];
						String value = inputline.split(":")[3];
						if(dne==0){
							mcursor = new MatrixCursor(new String[]{"key","value"});
							mcursor.addRow(new String[]{key,value});
							dne=2;
						}
						else if(dne==1){
							Socket clSoc = new Socket(InetAddress.getByName(ip),getPortNo(pred));
							DataOutputStream dos=new DataOutputStream(clSoc.getOutputStream());
							dos.writeBytes("GOahead:"+pred+":"+key+":"+value);
							dos.close();
							clSoc.close();
							dne=0;
						}
					}



					int f=0;
					if(portStr.equals("5554"))
					{
						if(inputline.contains("Join"))
						{
							count++;
							if(count==1)
							{
								String genHashValueMsg = genHash(inputline.split(":")[1]);
								if(genHashValueMsg.compareTo(genHash("5554")) < 0){
									pred = inputline.split(":")[1];
									f=1;
								}else if(genHashValueMsg.compareTo(genHash("5554")) > 0){
									succ = inputline.split(":")[1];
									f=2;
								}

								if(inputline.split(":")[0].equals("5556"))
									clientSocket = new Socket(InetAddress.getByName(ip),11112);
								else if(inputline.split(":")[0].equals("5558"))
									clientSocket = new Socket(InetAddress.getByName(ip),11116);

								DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());

								if(f==1)
									dos.writeBytes("succ:5554:"+count);
								else if(f==2)
									dos.writeBytes("pred:5554:"+count);
								dos.close();
								clientSocket.close();

							}
							else if(count==2)
							{
								String genHashValueMsg = genHash(inputline.split(":")[1]);
								
								if(genHashValueMsg.compareTo(genHash("5554")) < 0){
									pred = inputline.split(":")[1];
								}else if(genHashValueMsg.compareTo(genHash("5554")) > 0){
									succ = inputline.split(":")[1];
								}

								Socket cSocket1 = new Socket(InetAddress.getByName(ip),11112);
								DataOutputStream d1=new DataOutputStream(cSocket1.getOutputStream());
								d1.writeBytes("succ:5554:"+count+":5558");
								d1.close();
								cSocket1.close();
								
								Socket cSocket2 = new Socket(InetAddress.getByName(ip),11116);
								DataOutputStream d2=new DataOutputStream(cSocket2.getOutputStream());
								d2.writeBytes("pred:5554:"+count+":5556");
								d2.close();
								cSocket2.close();
							}
							
						}

					}
					else if(portStr.equals("5556"))
					{
						if(inputline.contains("succ")||inputline.contains("pred"))
						{
							if(inputline.contains("succ"))
								{
								succ=inputline.split(":")[1];
								pred=succ;
								}
								
							else if(inputline.contains("pred"))
								{
								pred=inputline.split(":")[1];
								succ=pred;
								}
							count = Integer.parseInt(inputline.split(":")[2]);

							if(count==2)
							{
								pred=inputline.split(":")[3];
							}
						}
					}
					else if(portStr.equals("5558"))
					{
						if(inputline.contains("succ")||inputline.contains("pred")) 
						{
							if(inputline.contains("succ")){
								succ=inputline.split(":")[1];
								pred=succ;
							}
								
							else if(inputline.contains("pred"))
							{
								pred=inputline.split(":")[1];
								succ=pred;
							}count = Integer.parseInt(inputline.split(":")[2]);

							if(count==2)
							{
								succ=inputline.split(":")[3];
							}
						}
					}
				}
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return null;
		}

	}

	public class ClientTask extends AsyncTask<Void, String, Void>{

		Socket clientSocket=null;
		@Override
		protected Void doInBackground(Void... params) {
			try{
				 if(portStr.equals("5556"))
				{
					clientSocket = new Socket(InetAddress.getByName(ip),11108);
					DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());
					dos.writeBytes("Join:5556");
					dos.close();
					clientSocket.close();
				}
				else if(portStr.equals("5558"))
				{
					clientSocket = new Socket(InetAddress.getByName(ip),11108);
					DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());
					dos.writeBytes("Join:5558");
					dos.close();
					clientSocket.close();
				}
			}
			catch (Exception e) {
			}
			return null;
		}    	
	}
}
